

import hello_world


'''
def Delete_Everything():
    print("Delete everyhing in OS")

def hello_world():
    print("hello WOrld")




def hello_world2():
    print("hello WOrld")



def hello_world3():
    print("hello WOrld")




def hello_world4():
    print("hello WOrld")



def hello_world5():
    print("hello WOrld")


print(__name__)
if(__name__ == "__main__"):
    Delete_Everything()
   '''



import math,sys,os


print("\n \n ---->",__name__)