

def Delete_Everything():
    print("Delete everyhing in OS")

def hello_world():
    print("hello WOrld")




def hello_world2():
    print("hello WOrld")



def hello_world3():
    print("hello WOrld")




def hello_world4():
    print("hello WOrld")




def hello_world5():
    print("hello WOrld")





if(__name__ == "__main__"):
    print("The name of hello_world.py",__name__)
    Delete_Everything()